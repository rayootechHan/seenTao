package zLiger.mail;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;

public class MailAuthenticator extends Authenticator{
	  
	/** 
	 * 用户名和密码的验证 
	 * @author lgf 
	 * 
	 */
	  private String username="272098065";   
	  private String password="********";   
	    
	  public MailAuthenticator() { 
	    super(); 
	  } 
	    
	  /** 
	   * 设置验证的用户名和密码 
	   */
	  public MailAuthenticator(String userName , String password) { 
	    super(); 
	    this.username = userName; 
	    this.password = password; 
	  } 
	  protected PasswordAuthentication getPasswordAuthentication() 
	  {   
	    return new PasswordAuthentication(this.username,this.password);   
	  }   
	}